<?php
session_start();

// Conectare la baza de date
($conn = mysqli_connect("localhost", "root", "", "hanna_db")) or die("Conexiune esuata: " . mysqli_connect_error());

// Preluare categorie
$tip = isset($_GET["tip"]) ? mysqli_real_escape_string($conn, $_GET["tip"]) : "";

// Interogare produse din categorie
$cerere = "SELECT * FROM produse WHERE tip = '$tip'";
$rezultat = mysqli_query($conn, $cerere);
?>
<!-- CSS pentru notificări și buton rapid coș -->
<style>
/* Notificări */
.notification {
    position: fixed;
    top: 100px;
    right: 20px;
    background: white;
    border-radius: 4px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    padding: 15px 20px;
    z-index: 10000;
    transform: translateX(150%);
    transition: transform 0.3s ease;
    min-width: 300px;
    border-left: 4px solid #4CAF50;
}

.notification.show {
    transform: translateX(0);
}

.notification.error {
    border-left-color: #f44336;
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    color: #333;
}

.notification-icon {
    font-weight: bold;
    font-size: 16px;
}

.notification.success .notification-icon {
    color: #4CAF50;
}

.notification.error .notification-icon {
    color: #f44336;
}

/* Buton rapid pentru coș */
.quick-cart-link {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #000;
    color: white;
    padding: 12px 20px;
    border-radius: 30px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 999;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.3s ease;
}

.quick-cart-link.show {
    opacity: 1;
    transform: translateY(0);
}

.quick-cart-link:hover {
    background: #333;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.3);
}
</style>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($tip); ?> - Hanna's Boutique</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/products.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="js/cart.js"></script>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="index.php">Hanna's <span>Boutique</span></a>
            </div>
            
            <nav class="main-nav">
                <a href="index.php">Acasă</a>
                <?php
                // Afișează toate categoriile
                $cerere_categorii = "SELECT DISTINCT tip FROM produse";
                $rez_categorii = mysqli_query($conn, $cerere_categorii);
                while ($categorie = mysqli_fetch_assoc($rez_categorii)): ?>
                    <a href="categorie.php?tip=<?php echo urlencode($categorie["tip"]); ?>"
                       <?php echo $categorie["tip"] == $tip ? 'style="color:#000;font-weight:bold;"' : ""; ?>>
                        <?php echo htmlspecialchars($categorie["tip"]); ?>
                    </a>
                <?php endwhile;
                ?>
            </nav>
            
            <div class="header-actions">
                <a href="cos.php" class="cart-icon">
                    <i class="fas fa-shopping-bag"></i>
                    <?php if ($_SESSION["nrprod"] > 0): ?>
                        <span class="cart-count"><?php echo $_SESSION["nrprod"]; ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </header>

    <!-- Pagina categoriei -->
    <section class="category-page">
        <div class="container">
            <div class="page-header">
                <h1><?php echo htmlspecialchars($tip); ?></h1>
                <p><?php echo mysqli_num_rows($rezultat); ?> produse</p>
            </div>
            
            <?php if (mysqli_num_rows($rezultat) == 0): ?>
                <div class="empty-category">
                    <p>Nu există produse în această categorie momentan.</p>
                    <a href="index.php" class="btn-primary">Înapoi la acasă</a>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php while ($produs = mysqli_fetch_assoc($rezultat)):

                        $imagine = !empty($produs["imagine"]) ? $produs["imagine"] : "default.jpg";
                        $descriere = !empty($produs["descriere"])
                            ? substr($produs["descriere"], 0, 100) . "..."
                            : "Descriere indisponibilă";
                        ?>
                        <div class="product-card">
                            <div class="product-image">
                                <img src="imagini/<?php echo htmlspecialchars($imagine); ?>" 
                                     alt="<?php echo htmlspecialchars($produs["nume"]); ?>"
                                     onerror="this.src='imagini/default.jpg'">
                            </div>
                            <div class="product-info">
                                <h3><?php echo htmlspecialchars($produs["nume"]); ?></h3>
                                <p class="product-description"><?php echo htmlspecialchars($descriere); ?></p>
                                <p class="product-price"><?php echo number_format(
                                    $produs["pret"],
                                    0,
                                    ",",
                                    "."
                                ); ?> RON</p>
                                
                                <form action="adauga_cos.php" method="POST" class="add-to-cart-form">
                                    <input type="hidden" name="codp" value="<?php echo $produs["codp"]; ?>">
                                    <input type="hidden" name="nume" value="<?php echo htmlspecialchars(
                                        $produs["nume"]
                                    ); ?>">
                                    <input type="hidden" name="pret" value="<?php echo $produs["pret"]; ?>">
                                    <input type="hidden" name="imagine" value="<?php echo htmlspecialchars(
                                        $imagine
                                    ); ?>">
                                    
                                    <div class="quantity-selector">
                                        <label for="cantitate_<?php echo $produs["codp"]; ?>">Cantitate:</label>
                                        <input type="number" 
                                               name="cantitate" 
                                               id="cantitate_<?php echo $produs["codp"]; ?>" 
                                               value="1" 
                                               min="1" 
                                               class="quantity-input">
                                    </div>
                                    
                                    <button type="submit" class="btn-add-to-cart">
                                        <i class="fas fa-shopping-bag"></i> Adaugă în coș
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php
                    endwhile; ?>
                </div>
            <?php endif; ?>
            
            <div class="back-to-home">
                <a href="index.php" class="btn-secondary">
                    <i class="fas fa-arrow-left"></i> Înapoi la categorii
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3> Hanna's Boutique</h3>
                    <p>Magazin online de modă</p>
                </div>
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>Email: contact@hannaboutique.ro</p>
                    <p>Telefon: 0722 222 222</p>
                </div>
                <div class="footer-section">
                    <h3>Link-uri utile</h3>
                    <a href="index.php">Acasă</a>
                    <a href="cos.php">Coș de cumpărături</a>
                </div>
            </div>
            <p class="copyright">&copy; 2026 Hanna's Boutique. Toate drepturile rezervate.</p>
        </div>
    </footer>

    <?php mysqli_close($conn); ?>
</body>
</html>