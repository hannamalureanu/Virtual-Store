<?php
session_start();

if (!isset($_SESSION['cos'])) {
    $_SESSION['cos'] = [];
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
}

// Variabilă pentru a ști dacă afișăm mesajul de comandă finalizată
$comanda_finalizata = false;

// Procesare ștergere produs
if (isset($_GET['sterge'])) {
    $codp_sterge = $_GET['sterge'];
    
    // Șterge produsul folosind codp ca cheie
    if (isset($_SESSION['cos'][$codp_sterge])) {
        unset($_SESSION['cos'][$codp_sterge]);
    }
    
    // Recalculăm totalurile
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
    
    foreach ($_SESSION['cos'] as $item) {
        $_SESSION['total'] += $item['subtotal'];
        $_SESSION['nrprod'] += $item['cantitate'];
    }
    
    header("Location: cos.php");
    exit();
}

// Procesare actualizare cantități
if (isset($_POST['actualizeaza'])) {
    // Parcurge fiecare cantitate trimisă din formular
    foreach ($_POST['cantitate'] as $codp => $new_qty) {
        $codp = intval($codp);
        $new_qty = intval($new_qty);
        
        // Verifică dacă produsul există în coș
        if (isset($_SESSION['cos'][$codp])) {
            if ($new_qty > 0) {
                // Actualizează cantitatea
                $_SESSION['cos'][$codp]['cantitate'] = $new_qty;
                $_SESSION['cos'][$codp]['subtotal'] = $_SESSION['cos'][$codp]['pret'] * $new_qty;
            } else {
                // Dacă cantitatea este 0, elimină produsul
                unset($_SESSION['cos'][$codp]);
            }
        }
    }
    
    // Recalculăm totalurile
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
    
    foreach ($_SESSION['cos'] as $item) {
        $_SESSION['total'] += $item['subtotal'];
        $_SESSION['nrprod'] += $item['cantitate'];
    }
    
    header("Location: cos.php");
    exit();
}

// Procesare finalizare comandă
if (isset($_POST['finalizeaza'])) {
    // Aici în producție ați salva comanda în baza de date
    
    // Golește coșul
    $_SESSION['cos'] = [];
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
    
    $comanda_finalizata = true;
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coș de cumpărături - Hanna's Boutique</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/cart.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="index.php">Hanna's <span>Boutique</span></a>
            </div>
            
            <nav class="main-nav">
                <a href="index.php">Acasă</a>
                <?php 
                // Conectare pentru a obține categoriile
                $conn = mysqli_connect("localhost", "root", "", "hanna_db");
                $cerere_categorii = "SELECT DISTINCT tip FROM produse";
                $rez_categorii = mysqli_query($conn, $cerere_categorii);
                while ($categorie = mysqli_fetch_assoc($rez_categorii)): 
                ?>
                    <a href="categorie.php?tip=<?php echo urlencode($categorie['tip']); ?>">
                        <?php echo htmlspecialchars($categorie['tip']); ?>
                    </a>
                <?php endwhile; 
                mysqli_close($conn);
                ?>
            </nav>
            
            <div class="header-actions">
                <a href="cos.php" class="cart-icon active">
                    <i class="fas fa-shopping-bag"></i>
                    <?php if ($_SESSION["nrprod"] > 0): ?>
                        <span class="cart-count"><?php echo $_SESSION["nrprod"]; ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </header>

    <!-- Pagina coșului -->
    <section class="cart-page">
        <div class="container">
            <h1>Coșul tău de cumpărături</h1>
            
            <?php if (isset($comanda_finalizata) && $comanda_finalizata): ?>
                <div class="order-success">
                    <div class="success-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <h2>Comanda a fost plasată cu succes!</h2>
                    <p>Mulțumim pentru cumpărături! Veți primi un email de confirmare în scurt timp.</p>
                    <a href="index.php" class="btn-primary">Continuă cumpărăturile</a>
                </div>
            <?php elseif (empty($_SESSION['cos'])): ?>
                <div class="empty-cart">
                    <div class="empty-icon">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                    <h2>Coșul tău este gol</h2>
                    <p>Adaugă produse în coș pentru a finaliza o comandă</p>
                    <a href="index.php" class="btn-primary">Vezi produse</a>
                </div>
            <?php else: ?>
                <div class="cart-content">
                    <div class="cart-items">
                        <form action="cos.php" method="post">
                            <table class="cart-table">
                                <thead>
                                    <tr>
                                        <th>Produs</th>
                                        <th>Preț</th>
                                        <th>Cantitate</th>
                                        <th>Subtotal</th>
                                        <th>Acțiuni</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($_SESSION['cos'] as $codp => $item): ?>
                                        <tr class="cart-item">
                                            <td class="product-info">
                                                <div class="product-image">
                                                    <img src="imagini/<?php echo htmlspecialchars($item['imagine']); ?>" 
                                                         alt="<?php echo htmlspecialchars($item['nume']); ?>"
                                                         onerror="this.src='imagini/default.jpg'">
                                                </div>
                                                <div class="product-details">
                                                    <h3><?php echo htmlspecialchars($item['nume']); ?></h3>
                                                    <p>Cod produs: <?php echo $codp; ?></p>
                                                </div>
                                            </td>
                                            <td class="product-price">
                                                <?php echo number_format($item['pret'], 0, ',', '.'); ?> RON
                                            </td>
                                            <td class="product-quantity">
                                                <input type="number" 
                                                       name="cantitate[<?php echo $codp; ?>]" 
                                                       value="<?php echo $item['cantitate']; ?>" 
                                                       min="0" 
                                                       class="quantity-input">
                                            </td>
                                            <td class="product-subtotal">
                                                <?php echo number_format($item['subtotal'], 0, ',', '.'); ?> RON
                                            </td>
                                            <td class="product-actions">
                                                <a href="cos.php?sterge=<?php echo $codp; ?>" 
                                                   class="remove-item"
                                                   onclick="return confirm('Sigur doriți să eliminați acest produs din coș?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                            
                            <div class="cart-actions">
                                <button type="submit" name="actualizeaza" class="btn-secondary">
                                    <i class="fas fa-sync-alt"></i> Actualizează coșul
                                </button>
                                <a href="index.php" class="btn-continue">
                                    <i class="fas fa-arrow-left"></i> Continuă cumpărăturile
                                </a>
                            </div>
                        </form>
                    </div>
                    
                    <div class="cart-summary">
                        <h3>Sumar comandă</h3>
                        <div class="summary-row">
                            <span>Produse:</span>
                            <span><?php echo $_SESSION['nrprod']; ?> buc</span>
                        </div>
                        <div class="summary-row total">
                            <span>Total:</span>
                            <span class="total-price"><?php echo number_format($_SESSION['total'], 0, ',', '.'); ?> RON</span>
                        </div>
                        
                        <form action="cos.php" method="post" onsubmit="return confirm('Sigur doriți să finalizați comanda?')">
                            <button type="submit" name="finalizeaza" class="btn-checkout">
                                <i class="fas fa-lock"></i> Finalizează comanda
                            </button>
                        </form>
                        
                        <p class="secure-checkout">
                            <i class="fas fa-shield-alt"></i> Plata securizată
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Hanna's Boutique</h3>
                    <p>Magazin online de modă</p>
                </div>
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>Email: contact@hannaboutique.ro</p>
                    <p>Telefon: 0722 222 222</p>
                </div>
                <div class="footer-section">
                    <h3>Link-uri utile</h3>
                    <a href="index.php">Acasă</a>
                    <a href="cos.php">Coș de cumpărături</a>
                </div>
            </div>
            <p class="copyright">&copy; 2026 Hanna's Boutique. Toate drepturile rezervate.</p>
        </div>
    </footer>
</body>
</html>