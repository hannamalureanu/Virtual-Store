<?php
session_start();

// Inițializează coșul dacă nu există
if (!isset($_SESSION['cos'])) {
    $_SESSION['cos'] = [];
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
}

// Dacă este cerere AJAX (trimitere din JavaScript)
if (isset($_POST['ajax']) && $_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['codp'])) {
    $codp = intval($_POST['codp']);
    $cantitate = isset($_POST['cantitate']) ? intval($_POST['cantitate']) : 1;
    
    if ($cantitate < 1) {
        $cantitate = 1;
    }
    
    // Verifică dacă produsul există deja în coș (folosind codp ca cheie)
    if (isset($_SESSION['cos'][$codp])) {
        // Produsul există - actualizează cantitatea
        $_SESSION['cos'][$codp]['cantitate'] += $cantitate;
        $_SESSION['cos'][$codp]['subtotal'] = $_SESSION['cos'][$codp]['pret'] * $_SESSION['cos'][$codp]['cantitate'];
    } else {
        // Produsul nu există - adaugă intrare nouă
        $_SESSION['cos'][$codp] = [
            'codp' => $codp,
            'nume' => $_POST['nume'],
            'pret' => floatval($_POST['pret']),
            'cantitate' => $cantitate,
            'imagine' => $_POST['imagine'],
            'subtotal' => floatval($_POST['pret']) * $cantitate
        ];
    }
    
    // Recalculează totalurile
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
    
    foreach ($_SESSION['cos'] as $item) {
        $_SESSION['total'] += $item['subtotal'];
        $_SESSION['nrprod'] += $item['cantitate'];
    }
    
    // Returnează răspuns JSON pentru AJAX
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'message' => 'Produs adăugat în coș',
        'nrprod' => $_SESSION['nrprod'],
        'total' => $_SESSION['total'],
        'produse_in_cos' => count($_SESSION['cos'])
    ]);
    exit();
}
// Dacă NU este cerere AJAX (fallback pentru browsere fără JavaScript)
else if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['codp'])) {
    $codp = intval($_POST['codp']);
    $cantitate = isset($_POST['cantitate']) ? intval($_POST['cantitate']) : 1;
    
    if ($cantitate < 1) {
        $cantitate = 1;
    }
    
    // Verifică dacă produsul există deja în coș (folosind codp ca cheie)
    if (isset($_SESSION['cos'][$codp])) {
        // Produsul există - actualizează cantitatea
        $_SESSION['cos'][$codp]['cantitate'] += $cantitate;
        $_SESSION['cos'][$codp]['subtotal'] = $_SESSION['cos'][$codp]['pret'] * $_SESSION['cos'][$codp]['cantitate'];
    } else {
        // Produsul nu există - adaugă intrare nouă
        $_SESSION['cos'][$codp] = [
            'codp' => $codp,
            'nume' => $_POST['nume'],
            'pret' => floatval($_POST['pret']),
            'cantitate' => $cantitate,
            'imagine' => $_POST['imagine'],
            'subtotal' => floatval($_POST['pret']) * $cantitate
        ];
    }
    
    // Recalculează totalurile
    $_SESSION['total'] = 0;
    $_SESSION['nrprod'] = 0;
    
    foreach ($_SESSION['cos'] as $item) {
        $_SESSION['total'] += $item['subtotal'];
        $_SESSION['nrprod'] += $item['cantitate'];
    }
    
    // Redirecționează înapoi (fallback pentru browsere fără JavaScript)
    $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
    header("Location: $referer?added_to_cart=true");
    exit();
} else {
    // Dacă accesează direct fișierul
    header("Location: index.php");
    exit();
}
?>