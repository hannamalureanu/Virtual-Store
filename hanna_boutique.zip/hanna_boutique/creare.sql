SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hanna_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `produse`
--

CREATE TABLE `produse` (
  `codp` int(4) NOT NULL,
  `nume` varchar(20) DEFAULT NULL,
  `pret` int(8) DEFAULT NULL,
  `descriere` TEXT,
  `imagine` varchar(100),
  `tip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `produse`
--

INSERT INTO `produse` (`codp`, `nume`, `pret`, `descriere`, `imagine`, `tip`) VALUES
(1, 'ADIDAS SPORT', 300, 'Adidas sport, talpa confortabila, marimea 37', 'adidas_sport.jpg', 'INCALTAMINTE'),
(2, 'BOCANCI', 400, 'Bocanci clasici negri, piele naturala', 'bocanci.jpg', 'INCALTAMINTE'),
(3, 'PANTOFI', 600, 'Pantofi stiletto de calitate superioara', 'pantofi.jpg', 'INCALTAMINTE'),
(4, 'CIZME', 800, 'Cizme dama lungi cu toc, piele naturala neagra ', 'cizme.jpg', 'INCALTAMINTE'),
(5, 'CAMASA ALBA', 300, 'Camasa alba simpla,din bumbac 100%', 'camasa_alba.jpg', 'IMBRACAMINTE'),
(6, 'PULLOVER NEGRU', 700, 'Pullover negru, din casmir 100%', 'pullover_negru.jpg', 'IMBRACAMINTE'),
(7, 'ROCHIE DE SEARA', 300, 'Rochie lunga de seara, neagra,din vascoza 100%', 'rochie_de_seara.jpg', 'IMBRACAMINTE'),
(8, 'BLUGI', 170, 'Blugi albastri, wide leg, marimea 38', 'blugi.jpg', 'IMBRACAMINTE'),
(9, 'TRICOU', 100, 'Tricou portocaliu, marimea M, 50% bumbac', 'tricou.jpg', 'IMBRACAMINTE'),
(10, 'FUSTA TENIS', 50, 'Fusta tenis alba, marimea S', 'fusta_tenis.jpg', 'IMBRACAMINTE'),
(11, 'FUSTA MINI', 80, 'Fusta mini plisata, neagra, marimea M', 'fusta_mini.jpg', 'IMBRACAMINTE'),
(12, 'COLANTI', 100, 'Colanti sport dama, bleu, talie inalta', 'colanti.jpg', 'IMBRACAMINTE'),
(13, 'SWEATPANTS', 150, 'Pantaloni de alergat dama, gri, bumbac 70%', 'sweatpants.jpg', 'IMBRACAMINTE'),
(14, 'COMPLEU STOFA', 1000, 'Compleu de dama din stofa, doua piese: vesta cu inchidere nasturi si pantaloni', 'compleu_stofa.jpg', 'SETURI'),
(15, 'COMPLEU BUMBAC', 500, 'Compleu de dama, doua piese: jacheta cu inchidere capse si pantalon lejer din bumbac', 'compleu_bumbac.jpg', 'SETURI'),
(16, 'COSTUM DE BAIE', 600, 'Costum de baie doua piese, marimea S', 'costum_de_baie.jpg', 'SETURI'),
(17, 'FULAR', 150, 'Fular negru din casmir, design simplu', 'fular.jpg', 'ACCESORII'),
(18, 'MANUSI', 50, 'Manusi calduroase din lana', 'manusi.jpg', 'ACCESORII'),
(19, 'GEANTA', 1500, 'Geanta din piele naturala, neagra', 'geanta.jpg', 'ACCESORII'),
(20, 'COLIER', 500, 'Colier cu pandantiv, din argint', 'colier.jpg', 'ACCESORII'),
(21, 'CERCEI', 400, 'Cercei din argint, planeta Saturn', 'cercei.jpg', 'ACCESORII'),
(22, 'OCHELARI DE SOARE', 150, 'Ochelari de soare polarizati, design modern', 'ochelari_de_soare.jpg', 'ACCESORII');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `produse`
--
ALTER TABLE `produse`
  ADD PRIMARY KEY (`codp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produse`
--
ALTER TABLE `produse`
  MODIFY `codp` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;