<?php
session_start();

// Inițializează variabilele sesiunii dacă nu există
if (!isset($_SESSION["intrat"])) {
    $_SESSION["intrat"] = 1;
    $_SESSION["nrprod"] = 0;
    $_SESSION["total"] = 0;
    $_SESSION["cos"] = [];
}

// Conectare la baza de date
$conn = mysqli_connect("localhost", "root", "", "hanna_db") or 
    die("Conexiune esuata: " . mysqli_connect_error());

// Obține categorii distincte
$cerere = "SELECT DISTINCT tip FROM produse";
$rezultat = mysqli_query($conn, $cerere) or 
    die("Cerere SQL esuata: " . mysqli_error($conn));
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hanna's Boutique</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="js/cart.js"></script>
</head>

<!-- CSS pentru notificări și buton rapid coș -->
<style>
/* Notificări */
.notification {
    position: fixed;
    top: 100px;
    right: 20px;
    background: white;
    border-radius: 4px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    padding: 15px 20px;
    z-index: 10000;
    transform: translateX(150%);
    transition: transform 0.3s ease;
    min-width: 300px;
    border-left: 4px solid #4CAF50;
}

.notification.show {
    transform: translateX(0);
}

.notification.error {
    border-left-color: #f44336;
}

.notification-content {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 14px;
    color: #333;
}

.notification-icon {
    font-weight: bold;
    font-size: 16px;
}

.notification.success .notification-icon {
    color: #4CAF50;
}

.notification.error .notification-icon {
    color: #f44336;
}

/* Buton rapid pentru coș */
.quick-cart-link {
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: #000;
    color: white;
    padding: 12px 20px;
    border-radius: 30px;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 999;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.3s ease;
}

.quick-cart-link.show {
    opacity: 1;
    transform: translateY(0);
}

.quick-cart-link:hover {
    background: #333;
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.3);
}
</style>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="index.php">Hanna's <span>Boutique</span></a>
            </div>
            
            <nav class="main-nav">
                <a href="index.php">Acasă</a>
                <?php while ($linie = mysqli_fetch_assoc($rezultat)): ?>
                    <a href="categorie.php?tip=<?php echo urlencode($linie['tip']); ?>">
                        <?php echo htmlspecialchars($linie['tip']); ?>
                    </a>
                <?php endwhile; ?>
            </nav>
            
            <div class="header-actions">
                <a href="cos.php" class="cart-icon">
                    <i class="fas fa-shopping-bag"></i>
                    <?php if ($_SESSION["nrprod"] > 0): ?>
                        <span class="cart-count"><?php echo $_SESSION["nrprod"]; ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Colecția de toamnă 2026</h1>
            <p>Descoperă ultimele trenduri în modă</p>
            <a href="#categorii" class="btn-primary">Vezi colecția</a>
        </div>
    </section>

    <!-- Categorii -->
    <section id="categorii" class="categories">
        <div class="container">
            <h2 class="section-title">Categorii</h2>
            <div class="categories-grid">
                <?php 
                mysqli_data_seek($rezultat, 0); // Reset pointer
                while ($linie = mysqli_fetch_assoc($rezultat)): 
                    $tip = $linie['tip'];
                    
                    // Obține primul produs din categorie pentru imagine
                    $cerere_produs = "SELECT imagine FROM produse WHERE tip = '$tip' LIMIT 1";
                    $rez_produs = mysqli_query($conn, $cerere_produs);
                    $produs = mysqli_fetch_assoc($rez_produs);
                    $imagine = !empty($produs['imagine']) ? $produs['imagine'] : 'default.jpg';
                ?>
                    <div class="category-card">
                        <div class="category-image">
                            <img src="imagini/<?php echo htmlspecialchars($imagine); ?>" 
                                 alt="<?php echo htmlspecialchars($tip); ?>"
                                 onerror="this.src='imagini/default.jpg'">
                        </div>
                        <div class="category-content">
                            <h3><?php echo htmlspecialchars($tip); ?></h3>
                            <a href="categorie.php?tip=<?php echo urlencode($tip); ?>" class="btn-secondary">
                                Vezi produsele
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Hanna's Boutique</h3>
                    <p>Magazin online de modă</p>
                </div>
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>Email: contact@hannaboutique.ro</p>
                    <p>Telefon: 0722 222 222</p>
                </div>
                <div class="footer-section">
                    <h3>Link-uri utile</h3>
                    <a href="index.php">Acasă</a>
                    <a href="cos.php">Coș de cumpărături</a>
                </div>
            </div>
            <p class="copyright">&copy; 2026  Hanna's Boutique. Toate drepturile rezervate.</p>
        </div>
    </footer>

    <?php mysqli_close($conn); ?>
</body>
</html>