// Funcție pentru adăugarea produsului în coș prin AJAX
function adaugaInCos(formElement) {
    // Colectează datele din formular
    const formData = new FormData(formElement);
    formData.append('ajax', 'true');
    
    // Afișează indicator de încărcare
    const button = formElement.querySelector('.btn-add-to-cart');
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Se adaugă...';
    button.disabled = true;
    
    // Trimite cererea AJAX
    fetch('adauga_cos.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Afișează mesaj de succes
            showNotification('✅ Produs adăugat în coș!', 'success');
            
            // Actualizează numărul din iconița coșului
            updateCartIcon(data.nrprod);
            
            // Afișează butonul rapid pentru coș
            showQuickCartLink();
        } else {
            showNotification('❌ Eroare: ' + data.message, 'error');
        }
        
        // Restaurează butonul
        button.innerHTML = originalText;
        button.disabled = false;
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('❌ Eroare de conexiune', 'error');
        
        // Restaurează butonul
        button.innerHTML = originalText;
        button.disabled = false;
    });
}

// Funcție pentru afișarea notificărilor
function showNotification(message, type = 'success') {
    // Șterge notificările vechi
    const oldNotification = document.querySelector('.notification');
    if (oldNotification) {
        oldNotification.remove();
    }
    
    // Creează notificarea nouă
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${type === 'success' ? '✓' : '✗'}</span>
            <span class="notification-text">${message}</span>
        </div>
    `;
    
    // Adaugă notificarea în pagină
    document.body.appendChild(notification);
    
    // Afișează notificarea cu animație
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Ascunde notificarea după 3 secunde
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
            }
        }, 300);
    }, 3000);
}

// Funcție pentru actualizarea iconiței coșului
function updateCartIcon(count) {
    const cartIcon = document.querySelector('.cart-icon');
    if (!cartIcon) return;
    
    let cartCount = cartIcon.querySelector('.cart-count');
    
    if (count > 0) {
        if (!cartCount) {
            cartCount = document.createElement('span');
            cartCount.className = 'cart-count';
            cartIcon.appendChild(cartCount);
        }
        cartCount.textContent = count;
    } else if (cartCount) {
        cartCount.remove();
    }
}

// Funcție pentru afișarea butonului rapid pentru coș
function showQuickCartLink() {
    let quickLink = document.querySelector('.quick-cart-link');
    
    if (!quickLink) {
        quickLink = document.createElement('a');
        quickLink.className = 'quick-cart-link';
        quickLink.href = 'cos.php';
        quickLink.innerHTML = `
            <i class="fas fa-shopping-bag"></i>
            <span>Vezi coșul</span>
        `;
        document.body.appendChild(quickLink);
        
        // Afișează cu animație
        setTimeout(() => {
            quickLink.classList.add('show');
        }, 100);
    }
    
    // Ascunde automat după 5 secunde
    setTimeout(() => {
        if (quickLink && quickLink.classList.contains('show')) {
            quickLink.classList.remove('show');
            setTimeout(() => {
                if (quickLink.parentNode) {
                    quickLink.remove();
                }
            }, 300);
        }
    }, 5000);
}

// Inițializează toate form-urile la încărcarea paginii
document.addEventListener('DOMContentLoaded', function() {
    // Găsește toate form-urile de adăugare în coș
    const forms = document.querySelectorAll('.add-to-cart-form');
    
    forms.forEach(form => {
        // Împiedică submit-ul normal al formularului
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            adaugaInCos(this);
        });
    });
    
    // Permite și adăugarea rapidă cu dublu-clic pe imaginea produsului
    const productImages = document.querySelectorAll('.product-image');
    productImages.forEach(image => {
        image.addEventListener('dblclick', function(e) {
            const form = this.closest('.product-card').querySelector('.add-to-cart-form');
            if (form) {
                adaugaInCos(form);
            }
        });
    });
});